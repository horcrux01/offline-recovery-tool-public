# offline-recovery-tool-public


1. Install npm: https://nodejs.org/en

2. Open the terminal in your machine and run `npm -v` to verify the installation

3. Install git, run the commands `winget install --id GitHub.cli` then `winget upgrade --id GitHub.cli`

4. `git clone https://github.com/horcrux01/offline-recovery-tool-public.git`

5. `cd offline-recovery-tool-public`

6. `npm install --global yarn`

7. `yarn --version`

8. `yarn install`

9. `yarn run dev` (Tool would open in the browser at http://localhost:5173/)
