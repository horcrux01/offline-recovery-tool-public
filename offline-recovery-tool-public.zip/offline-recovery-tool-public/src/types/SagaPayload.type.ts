export interface SagaPayloadType {
  type: string;
}
